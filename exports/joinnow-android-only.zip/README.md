# JoinNow Android

Standalone Expo Android wrapper for the hosted JoinNow application.

This folder contains fewer than 100 files and can be uploaded to a new Git repository in one browser upload. The Android APK build profile is defined in `eas.json`.

The app displays the hosted JoinNow website, so the JoinNow web application and API server must remain deployed and online.
